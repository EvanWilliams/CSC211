import java.util.*;
import java.io.*;

public class GetFile
{

	public static void main(String args[]) throws FileNotFoundException{
		
		Scanner scan = null;
		
			scan = new Scanner(new FileInputStream("C:/Projects/CSC211/Lab2(prelab)/Data/testbank.dat"));
		
		
		int count=0;
		
		while (scan.hasNext()) {
			String text = scan.nextLine();
			
			count++;
			System.out.println(count+ ") " +text);
		}


	}
// Output
//	1) 5
//	2) e
//	3) 5
//	4) Why does the constructor of a derived class have to call the constructor of its parent class?
//	5) m
//	6) 4
//	7) Which of the following is not a legal identifier in Java?
//	8) guess2
//	9) 2ndGuess
//	10) _guess2_
//	11) Guess
//	12) e
//	13) 10
//	14) How do interfaces provide polymorphism in Java?
//	15) e
//	16) 3
//	17) Java does not support multiple inheritance.  This means that a class cannot do what?
//	18) m
//	19) 3
//	20) A JPanel has an <i>addMouseListener</i> method because JPanel is a subclass of
//	21) JComponent
//	22) JApplet
//	23) Object
}